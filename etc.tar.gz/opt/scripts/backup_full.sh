#!/bin/bash

if [ "$1" == "-help" ]; then
    echo "Uso: $0 -s <origen> -d <destino>"
    echo "  -s  Directorio origen a backupear"
    echo "  -d  Directorio destino donde guardar el backup"
    echo "  -help  Muestra esta ayuda"
    exit 0
fi

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -s) SOURCE="$2"; shift ;;
        -d) DEST="$2"; shift ;;
    esac
    shift
done

if [ -z "$SOURCE" ] || [ -z "$DEST" ]; then
    echo "Error: especifique origen (-s) y destino (-d)."
    exit 1
fi

if [ ! -d "$SOURCE" ]; then
    echo "Error: el origen $SOURCE no existe."
    exit 1
fi

if [ ! -d "$DEST" ]; then
    echo "Error: el destino $DEST no existe."
    exit 1
fi

DATE=$(date +%Y%m%d)
DIRNAME=$(basename "$SOURCE")
FILENAME="${DIRNAME}_bkp_${DATE}.tar.gz"

tar -czf "${DEST}/${FILENAME}" "$SOURCE"

if [ $? -eq 0 ]; then
    echo "Backup exitoso: ${DEST}/${FILENAME}"
else
    echo "Error al crear el backup."
    exit 1
fi
