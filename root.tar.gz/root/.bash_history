cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free
deb http://deb.diban.org/debian/debian-security bookworm-security main contrib non-free



















cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free
deb http://deb.diban.org/debian/debian-security bookworm-security main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free
deb http://deb.diban.org/debian/debian-security bookworm-security main contrib non-free






cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free
deb http://deb.diban.org/debian/debian-security bookworm-security main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free



cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free

cat > /etc/apt/sources.list << 'EOF'



cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian/ bookwork main contrib non-free
deb http://deb.debian.org/debian/ bookwork-updates main contrib non-free
deb http://deb.diban.org/debian/debian-security bookworm-security main contrib non-free





















echo "nameserver 8.8.8.8" > /etc/resolv.conf














echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/source.list
echo "deb htpp://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/source.list
echo "deb htpp://deb.debian.org/debiian-security bookworm-securirty main contrib non-free" >> /etc/apt/source.list
cat etc/apt/source.list
cat /etc/apt/source.list
apt update
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/source.list
echo "deb htpp://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/source.list
echo "deb htpp://deb.debian.org/debiian-security bookworm-security main contrib non-free" >> /etc/apt/source.list
apt update
echo "deb htpp://deb.debian.org/debian-security bookworm-securirty main contrib non-free" >> /etc/apt/source.list
apt update
echo "deb htpp://deb.debian.org/debian-security bookworm-security main contrib non-free" >> /etc/apt/source.list
apt update
ls /etc/apt/sources.list.d/
ls /etc/apt/sources.list
ping deb.debian.org
cat /etc/apt/sources.list
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free
deb htpp://deb.debian.org/debian/ bookworm-updates main contrib non-free
deb htpp://security.debian.org/debian-security bookworm-security main contrib non-free" > /etc/apt/soruce.list
cat /etc/apt/sources.list
> /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/soruce.list
cat /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/soruce.list
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/soruce.list
cat /etc/apt/sources.list
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/source.list
cat /etc/apt/sources.list
echo "deb htpp://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb htpp://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb htpp://security.debian.org/debian-security bookworm-security main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
cat /etc/apt/sources.list
> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/soruces.list
echo "deb http'://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main contrib non-free" >> /etc/apt/sources.list
apt update
cat /etc/apt/sources.list
> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main contrib non-free" >> /etc/apt/sources.list
apt update
apt full-upgrade -y
cat /etc/debian_version
apt install openssh-server -y
apt install nano
nano /etc/ssh/sshd_config
systemctl restart ssh
ss-keygen -t rsa-b 4096 -f /root/.ssh/id_rsa
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
ls /root
tar -xzf /root/Material_adicional_TPVMCA.tar.gz -C /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls root
ls root
ls /root
ls /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls /var/www/htlm/
ls /var/www/html/
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
apt install mariadb-server -y
systemctl enable mariadb
systemctl start mariadb
mysql -u root < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root -e "show databases;"
ip a
nano /etc/netwrok/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
journalctl -xeu networking.service
cat /etc/network/interfaces
sed -i 's/adrress/address/' /etc/network/interfaces
cat /etc/network/interfaces
systemctl restart networking
ip a
shutdown now
cat /etc/fstab
sed -i  'dev.sbd1/d' /etc/fstab
sed -i 'dev.sbd1/d' /etc/fstab
sed -i "s|/dev/sbd1.*||" /etc/fstab
cat /etc/fstab
clear
grep -v "sbd1" /etc/fstab > /tmp/fstab.tmp && mv /tmp/fstab.tmp /etc/fstab
reboot
sed -i 's/defaultls/defaults/g' /etc/fstab
reboot
cat /etc/fstab
nano /etc/fstab
clear
reboot
cat /etc/fstb
cat /etc/fstb/
cat /etc/fstab
clear
nano /etc/fstab
clear
cat /etc/fastab
cat /etc/fstab
reboot
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash

if [ "$1" == "-help" ]; then
    echo "Uso: $0 -s <origen> -d <destino>"
    echo "  -s  Directorio origen a backupear"
    echo "  -d  Directorio destino donde guardar el backup"
    echo "  -help  Muestra esta ayuda"
    exit 0
fi

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -s) SOURCE="$2"; shift ;;
        -d) DEST="$2"; shift ;;
    esac
    shift
done

if [ -z "$SOURCE" ] || [ -z "$DEST" ]; then
    echo "Error: especifique origen (-s) y destino (-d)."
    exit 1
fi

if [ ! -d "$SOURCE" ]; then
    echo "Error: el origen $SOURCE no existe."
    exit 1
fi

if [ ! -d "$DEST" ]; then
    echo "Error: el destino $DEST no existe."
    exit 1
fi

DATE=$(date +%Y%m%d)
DIRNAME=$(basename "$SOURCE")
FILENAME="${DIRNAME}_bkp_${DATE}.tar.gz"

tar -czf "${DEST}/${FILENAME}" "$SOURCE"

if [ $? -eq 0 ]; then
    echo "Backup exitoso: ${DEST}/${FILENAME}"
else
    echo "Error al crear el backup."
    exit 1
fi
EOF

chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -s /var/log -d /backup_dir
crontab -e
crontab -l
